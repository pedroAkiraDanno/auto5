# terraform-docs-samples
Terraform samples intended for inclusion in [cloud.google.com](https://cloud.google.com/).

Samples are sourced from https://github.com/GoogleCloudPlatform/magic-modules
